package com.example.appmain;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivityBrowser extends AppCompatActivity {

    private Button buttonURL;
    private EditText TextURL;
    private WebView WebBrowser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_browser);

        buttonURL = (Button)findViewById(R.id.buttonIr);
        TextURL = (EditText) findViewById(R.id.textURL);
        WebBrowser = (WebView)findViewById(R.id.webBrowser);

        WebBrowser.getSettings().setJavaScriptEnabled(true);
        WebBrowser.setWebViewClient(new WebViewClient());

        buttonURL.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                WebBrowser.loadUrl("http://"+TextURL.getText().toString());


            }
        });


    }
}