package com.example.appmain;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivityAgenda extends AppCompatActivity {

    TextView txtNome;
    TextView txtEmail;
    TextView txtFone;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_agenda);

        criarTabela();

        Button btnSalvar = (Button) findViewById(R.id.buttonSalvar);

        txtNome = (TextView) findViewById(R.id.editTextNome);
        txtEmail = (TextView) findViewById(R.id.editTextMail);
        txtFone = (TextView) findViewById(R.id.editTextFone);

        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try {

                    Contato c = new Contato();
                    c.setNome(txtNome.getText().toString());
                    c.setEmail(txtEmail.getText().toString());
                    c.setTelefone(txtFone.getText().toString());


                } catch (Exception ex){
                    Toast.makeText(getApplicationContext(), "Error Ocorreu", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }

    public void salvarContato(Contato c) {

        SQLiteDatabase db = null;

        try {

            db = openOrCreateDatabase("contatos.db", Context.MODE_PRIVATE, null);

            ContentValues contentInsert = new ContentValues();
            contentInsert.put("nome", c.getNome());
            contentInsert.put("email", c.getEmail());
            contentInsert.put("telefone", c.getTelefone());
            db.insert("contatos", null, contentInsert);

            txtNome.setText("");
            txtFone.setText("");
            txtEmail.setText("");


        }catch(Exception ex){
            Toast.makeText(getApplicationContext(),"Error ao inserir", Toast.LENGTH_SHORT).show();
        }finally {
            Toast.makeText(getApplicationContext(),"Dados Cadastrados", Toast.LENGTH_SHORT).show();
            db.close();
        }

    }

    private void criarTabela() {
        SQLiteDatabase db = openOrCreateDatabase("contatos.db", Context.MODE_PRIVATE, null);
        try{
            StringBuilder sql = new StringBuilder();
            sql.append("CREATE TABLE IF NOT EXISTS contatos(");
            sql.append("_id integer primary key autoincrement,");
            sql.append("nome varchar(120),");
            sql.append("email varchar(120),");
            sql.append("fone varchar(20))");

            db.execSQL(sql.toString());

        }catch(Exception ex){
            Toast.makeText(getApplicationContext(),"Error Ocorreu", Toast.LENGTH_LONG).show();
        }finally {
            db.close();
        }
    }
}