package com.example.appmain;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivityCalculadora extends AppCompatActivity {

    EditText ed1;
    EditText ed2;
    EditText edR;
    Button btnSom;
    Button btnSub;
    Button btnMulti;
    Button btnDiv;
    Button btnPercent;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_calculadora);

        ed1 = (EditText)findViewById(R.id.editTextVlr1);
        ed2 = (EditText)findViewById(R.id.editTextVlr2);
        edR = (EditText)findViewById(R.id.editTextResultado);
        btnSom = (Button)findViewById(R.id.buttonSoma);
        btnSub = (Button)findViewById(R.id.buttonSub);
        btnMulti = (Button)findViewById(R.id.buttonMulti);
        btnDiv = (Button)findViewById(R.id.buttonDiv);
        btnPercent = (Button)findViewById(R.id.buttonPercent);


        btnSom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double v1;
                Double v2;
                Double result;

                v1 = Double.parseDouble(ed1.getText().toString());
                v2 = Double.parseDouble(ed2.getText().toString());
                result = v1+v2;
                edR.setText(result.toString());

            }
        });

        btnSub.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double v1;
                Double v2;
                Double result;

                v1 = Double.parseDouble(ed1.getText().toString());
                v2 = Double.parseDouble(ed2.getText().toString());
                result = v1-v2;
                edR.setText(result.toString());

            }
        });

        btnMulti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double v1;
                Double v2;
                Double result;

                v1 = Double.parseDouble(ed1.getText().toString());
                v2 = Double.parseDouble(ed2.getText().toString());
                result = v1*v2;
                edR.setText(result.toString());

            }
        });

        btnPercent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double v1;
                Double v2;
                Double result;

                v1 = Double.parseDouble(ed1.getText().toString());
                v2 = Double.parseDouble(ed2.getText().toString());
                result = v1*v2/100;
                edR.setText(result.toString());

            }
        });

        btnDiv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Double v1;
                Double v2;
                Double result;

                v1 = Double.parseDouble(ed1.getText().toString());
                v2 = Double.parseDouble(ed2.getText().toString());
                result = v1/v2;
                edR.setText(result.toString());

            }
        });





    }
}